let balance = 50000;

function updateBalance() {
  document.getElementById("currentBalance").innerText =
    `$${balance.toLocaleString()}.00`;
}

function deposit() {
  let amount = prompt("Enter deposit amount:");
  amount = Number(amount);
  if (!amount || amount <= 0) return;
  balance += amount;
  updateBalance();
}

function withdraw() {
  let amount = prompt("Enter withdrawal amount:");
  amount = Number(amount);
  if (!amount || amount <= 0) return;
  if (amount > balance) {
    alert("Insufficient funds");
    return;
  }
  balance -= amount;
  updateBalance();
}
